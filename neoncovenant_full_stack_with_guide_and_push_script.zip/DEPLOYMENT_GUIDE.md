
# NeonCovenant Full Stack Deployment Guide

This guide walks you through deploying the full GAN-based document generation system for both staging and production.

---

## STAGING DEPLOYMENT (Local Docker Compose)

### Prerequisites
- Docker & Docker Compose
- Firebase Admin SDK credentials (JSON file)
- Stripe API keys
- Coinbase Commerce API key

### Steps

1. Clone the repository or unzip the project:
    ```bash
    git clone https://github.com/YOUR_USERNAME/neoncovenant-full-stack.git
    cd neoncovenant-full-stack
    ```

2. Add your secrets to `.env`:
    ```env
    LATENT_DIM=100
    LEARNING_RATE=0.0002
    BETA_1=0.5
    BATCH_SIZE=64
    EPOCHS=10000
    MODEL_SAVE_PATH=gan_generator.h5
    GENERATED_IMAGES_DIR=generated_images
    STRIPE_SECRET_KEY=your_stripe_secret_key
    STRIPE_WEBHOOK_SECRET=your_webhook_secret
    COINBASE_API_KEY=your_coinbase_api_key
    FIREBASE_CONFIG_PATH=firebase_config.json
    ```

3. Start the system:
    ```bash
    docker-compose -f docker-compose.full.yml up --build -d
    ```

4. Access the services:
    - API: http://localhost:5000
    - Portal: http://localhost:5173
    - Admin: http://localhost:3001
    - Finder: http://localhost:3002
    - Grafana: http://localhost:3003

---

## PRODUCTION DEPLOYMENT (Cloudflare + Zero Trust)

### Prerequisites
- Cloudflare account with domain (e.g., neoncovenant.com)
- Cloudflare Tunnel CLI (`cloudflared`)
- Firebase project set up
- GitHub repo (for CI/CD)

### 1. Setup Cloudflare Tunnels

```bash
cloudflared tunnel login
cloudflared tunnel create neon-docs
cloudflared tunnel route dns neon-docs api.neoncovenant.com
```

In `cloudflared/config.yml`:

```yaml
tunnel: neon-docs
credentials-file: /etc/cloudflared/credentials.json
ingress:
  - hostname: api.neoncovenant.com
    service: http://api:5000
  - hostname: portal.neoncovenant.com
    service: http://portal:5173
  - hostname: admin.neoncovenant.com
    service: http://admin:3000
  - hostname: finder.neoncovenant.com
    service: http://finder:3000
  - service: http_status:404
```

Start the tunnel:

```bash
docker-compose -f docker-compose.full.yml up -d cloudflared
```

### 2. Setup Firebase Authentication
- Enable Google Sign-In in Firebase Console
- Download Admin SDK JSON and reference it in `.env`
- Add auth guards to `/generate_document`, `/logs`, `/finder`

### 3. Setup GitHub Actions CI/CD
Use `.github/workflows/deploy.yml` to auto-deploy on push:
- Build containers
- Push images (optional)
- Restart services

---

## Monitoring

- Visit Grafana at `http://localhost:3003` or `metrics.neoncovenant.com`
- Dashboard includes:
  - API latency
  - Generation frequency
  - Service uptime

---

## Done!

You're now live with a production-grade GAN-based document generation and management platform.
