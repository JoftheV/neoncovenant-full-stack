#!/bin/bash

# Navigate to the project directory
cd "$(dirname "$0")"

# Initialize Git and push to your private GitHub repo
git init
git config user.name "JoftheV"
git config user.email "jofthev@users.noreply.github.com"
git remote add origin https://github.com/JoftheV/neoncovenant-full-stack.git
git add .
git commit -m "Initial full system commit"
git branch -M main
git push -u origin main
